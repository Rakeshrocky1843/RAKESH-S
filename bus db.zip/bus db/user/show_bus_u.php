<?php     
    session_start();
    require('../admin/function.php');
    $connection = mysqli_connect("localhost","root","");
    $db = mysqli_select_db($connection,"bms");
    $bus_no = "";
    $type = "";
    $r_id = "";
    $ori = "";
    $dst = "";
    
?>

<!doctype html>
<html lang="en">
  <head>
    <title>USer Show Bus</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <script src="https://kit.fontawesome.com/751afc7438.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    
  </head>
  <body>
      
    <nav class="navbar navbar-dark navbar-expand-sm navbar-color">
        <div class="container">
            <a class="navbar-brand" href=""><img src="bus 1.jpg" alt="" class="rounded-circle border" height="50" width="50"> Bus Reservation Management</a>
            <ul class="nav navbar-nav navbar navbar-right">
                <li class="nav-item "><a class="nav-link" href="user_dashboard.php"><i class="fa fa-home fa-md"></i>Home</a></li>
                <li class="nav-item active"><a class="nav-link" href="show_bus_u.php">Show bus</a></li>
                <li class="nav-item "><a class="nav-link btn-pd" href="logout.php"> <i class="fa fa-sign-out fa-md"></i> Logout</a></li> &nbsp      
            </ul>
        </div>
    </nav>

    <header class="jumbotron">
        <div class="container">
            <marquee class="text-center"><h5>! ! ! ! ! ! ! Welcome <?php echo $_SESSION['user_id'] ?> To Show Bus page  ! ! ! ! ! ! !<br>
                ....... Book yor ticket here .......</h5>
            </marquee>
        </div>
    </header>
    
    <div class="row">
        <div class="col-md-3" id="side_bar">
            <h5>Helps for</h5>
            <ul>
                <li>Bus management</li>
                <li>route management</li>
                <li>user management</li>
                <li>booking management</li>
            </ul>
        </div>
        <div class="col-8">
            <div class="d-flex p-2 bg-light text-white">
                <div class="p-2 bg-secondary">Total no of Bus :</div>
                <div class="p-2 bg-info">&nbsp &nbsp<?php echo get_bus_count() ?>&nbsp &nbsp</div>
            </div>

            <br>
            <table class="table table-hover table-bordered pd">
                <thead class="table-info">
                    <tr>
                        <th> Bus No </th>
                        <th>Route Id</th>
                        <th>type</th>
                        <th>Starting point</th>
                        <th>Destination point</th>
                        <th>Amount</th>
                    </tr>
                </thead>

                <!--Php show student-->

                <?php
                    
                    $query = "select bus.bus_no, bus.type, route.r_id, route.ori, route.dst, route.amt from bus left join route on bus.r_id = route.r_id order by r_id";
                    $query_run = mysqli_query($connection,$query);
                    while($row = mysqli_fetch_assoc($query_run))
                    {
                        $bus_no = $row['bus_no'];
                        $type = $row['type'];
                        $r_id = $row['r_id'];
                        $ori = $row['ori'];
                        $dst = $row['dst'];
                        $amt = $row['amt'];

                    ?>

                        <tr>
                            <td><?php echo $bus_no ?></td>
                            <td><?php echo $r_id ?></td>
                            <td><?php echo $type ?></td>
                            <td><?php echo $ori ?></td>
                            <td><?php echo $dst ?></td>
                            <td><i class="fa fa-inr"></i><?php echo $amt ?></td>
                        </tr>

                        <?php
                    }
                        
                ?>

            </table>
        </div>
    </div>

    <footer class="footer">
        <div class="container-fluid">
            <div class="row">             

            <div class="offset-1 col-lg-2 align-self-center">
                    <div class="text-center">
                        <p>
                            DBMS mini project <br>
                            Dept of CSE.
                        </p>
                    </div>
                </div>

                <div class="offset-1 col-lg-3">
                    <h6>Page creator</h6>
                    <h7>About Team</h7><br>
					Manohar E<br>
                    Kishore A<br>
					5 sem, CSE<br>
				    ACS College of Engineering<br>
                </div>
                
                
            </div>
        </div>

        <!-- Copyright -->
        <div class="footer-copyright text-center py-3">© 2020 Copyright
        </div>
        <!-- Copyright -->

    </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
