<?php
    session_start();
    $connection = mysqli_connect("localhost","root","");
    $db = mysqli_select_db($connection,"bms");
    $name = "";
    $pass_id = "";
    $gender = "";
    $age = "";
    $mobile = "";
    $r_id = "";
    $b_d = "";
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Show Ticket </title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <script src="https://kit.fontawesome.com/751afc7438.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    
  </head>
  <body>
      
    <nav class="navbar navbar-dark navbar-expand-sm navbar-color">
        <div class="container">
            <a class="navbar-brand" href=""><img src="bus 1.jpg" alt="" class="rounded-circle border" height="50" width="50"> Bus Reservation Management</a>
            <ul class="nav navbar-nav navbar navbar-right">
                <li class="nav-item "><a class="nav-link" href="user_dashboard.php"><i class="fa fa-home fa-md"></i>Home</a></li>
                <li class="nav-item "><a class="nav-link" href="show_bus_u.php">Show bus</a></li>
                <li class="nav-item "><a class="nav-link btn-pd" href="logout.php"> <i class="fa fa-sign-out fa-md"></i> Logout</a></li> &nbsp      
            </ul>
        </div>
    </nav>

    <header class="jumbotron">
        <div class="container">
            <marquee class="text-center"><h5>! ! ! ! ! ! ! Welcome <?php echo $_SESSION['user_id'] ?> To  Show Ticket page  ! ! ! ! ! ! !<br>
                ....... Book yor ticket here .......</h5>
            </marquee>
        </div>
    </header>
    
    <div class="row">
        <div class="col-md-3" id="side_bar">
            <h5>Helps for</h5>
            <ul>
                <li>Bus management</li>
                <li>route management</li>
                <li>user management</li>
                <li>booking management</li>
            </ul>
        </div>
        
        <div class="col-8 pd">
            <div class="col-5 pd">
                <form action="" method="post">
                    <div class="form-group">
                        <label > Enter Passenger Id :</label>
                        <input type="text" name="pass_id" class="form-control" required="">
                    </div>

                    <button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-search" aria-hidden="true"></i>Search</button>
                </form>
            </div>

            <table class="table table-hover table-bordered pd">
                <thead class="table-info">
                    <tr>
                        <th> Passenger ID </th>
                        <th> Name </th>
                        <th>Gender</th>
                        <th>Age</th>
                        <th>Mobile</th>
                        <th>Route ID</th>
                        <th>Booking Date</th>
                        <th> Options </th>
                    </tr>
                </thead>

                <!--Php show student-->

                <?php
                    
                    if(isset($_POST['submit']))
                    {
                        $query = "select * from booking where pass_id = $_POST[pass_id]";
                        $query_run = mysqli_query($connection,$query);
                        while($row = mysqli_fetch_assoc($query_run))
                        {
                            $pass_id = $row['pass_id'];
                            $name = $row['name'];
                            $gender = $row['gender'];
                            $age = $row['age'];
                            $mobile = $row['mobile'];
                            $r_id = $row['r_id'];
                            $b_d = $row['b_d'];

                        ?>

                            <tr>
                                <td><?php echo $pass_id ?></td>
                                <td><?php echo $name ?></td>
                                <td><?php echo $gender ?></td>
                                <td><?php echo $age ?></td>
                                <td><?php echo $mobile ?></td>
                                <td><?php echo $r_id ?></td>
                                <td><?php echo $b_d ?></td>
                                <td>
                                    <a type="button" class="btn btn-danger" href="delete_booking_u.php?id=<?php echo $row['pass_id'];?>">Delete</a>
                                    <a type="button" class="btn btn-success" href="update_booking_u.php?id=<?php echo $row['pass_id'];?>">update</a>
                                </td>
                            </tr>

                            <?php
                        }
                    }
                        
                ?>

            </table>
        </div>

    </div>

    <footer class="footer">
        <div class="container-fluid">
            <div class="row">             

            <div class="offset-1 col-lg-2 align-self-center">
                    <div class="text-center">
                        <p>
                            DBMS mini project <br>
                            Dept of CSE.
                        </p>
                    </div>
                </div>

                <div class="offset-1 col-lg-3">
                    <h6>Page creator</h6>
                    <h7>About Team</h7><br>
					Manohar E<br>
                    Kishore A<br>
					5 sem, CSE<br>
				    ACS College of Engineering<br>
                </div>
                
                
            </div>
        </div>

        <!-- Copyright -->
        <div class="footer-copyright text-center py-3">© 2020 Copyright
        </div>
        <!-- Copyright -->

    </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>

