<?php
	$connection = mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connection,"bms");
	$query = "delete from bus where bus_no = '$_GET[id]'";
	$query_run = mysqli_query($connection,$query);
?>
<script type="text/javascript">
	alert("Bus Deleted...");
	window.location.href = "show_bus.php";
</script>