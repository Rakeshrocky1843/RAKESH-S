<?php
	function get_bus_count(){
		$connection = mysqli_connect("localhost","root","");
		$db = mysqli_select_db($connection,"bms");
		$bus_count = "";
		$query = "select count(*) as bus_count from bus";
		$query_run = mysqli_query($connection,$query);
		while($row = mysqli_fetch_assoc($query_run)){
			$bus_count = $row['bus_count'];
		}
		return($bus_count);
    }

    function get_r_count(){
		$connection = mysqli_connect("localhost","root","");
		$db = mysqli_select_db($connection,"bms");
		$r_count = "";
		$query = "select count(*) as r_count from route";
		$query_run = mysqli_query($connection,$query);
		while($row = mysqli_fetch_assoc($query_run)){
			$r_count = $row['r_count'];
		}
		return($r_count);
    }

    function get_user_count(){
		$connection = mysqli_connect("localhost","root","");
		$db = mysqli_select_db($connection,"bms");
		$user_count = "";
		$query = "select count(*) as user_count from user";
		$query_run = mysqli_query($connection,$query);
		while($row = mysqli_fetch_assoc($query_run)){
			$user_count = $row['user_count'];
		}
		return($user_count);
    }

    function get_book_count(){
		$connection = mysqli_connect("localhost","root","");
		$db = mysqli_select_db($connection,"bms");
		$book_count = "";
		$query = "select count(*) as book_count from booking";
		$query_run = mysqli_query($connection,$query);
		while($row = mysqli_fetch_assoc($query_run)){
			$book_count = $row['book_count'];
		}
		return($book_count);
    }

?>