<?php
	$connection = mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connection,"bms");
	$query = "delete from booking where pass_id = '$_GET[id]'";
	$query_run = mysqli_query($connection,$query);
?>
<script type="text/javascript">
	alert("Booking Deleted...");
	window.location.href = "show_bookings.php";
</script>