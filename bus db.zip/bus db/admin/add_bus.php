<?php
    require("function.php");
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Add Bus </title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <script src="https://kit.fontawesome.com/751afc7438.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    
  </head>
  <body>
      
  <nav class="navbar navbar-dark navbar-expand-sm navbar-color">
        <div class="container">
            <a class="navbar-brand" href=""><img src="bus 1.jpg" alt="" class="rounded-circle border" height="50" width="50"> Bus Reservation Management</a>
            <ul class="nav navbar-nav navbar navbar-right">
                <li class="nav-item "><a class="nav-link" href="admin_dashboard.php"><i class="fa fa-home fa-md"></i>Home</a></li>
                <li class="nav-item "><a class="nav-link" href="show_user.php">Show user</a></li>
                <li class="nav-item "><a class="nav-link" href="show_bookings.php">Show bookings</a></li> 
                <div class="dropdown">
                    <a class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
                        Bus
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="add_bus.php">Add Bus</a>
                        <a class="dropdown-item" href="show_bus.php">show Bus</a>
                    </div>
                </div>  
                <div class="dropdown">
                    <a class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
                        Route
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="add_route.php">Add Route</a>
                        <a class="dropdown-item" href="show_route.php">show Route</a>
                    </div>
                </div>  
                <li class="nav-item "><a class="nav-link btn-pd" href="logout.php"> <i class="fa fa-sign-out fa-md"></i> Logout</a></li> &nbsp      
            </ul>
        </div>
    </nav>
    
    <div class="row">
        <div class="col-md-3" id="side_bar">
            <h5>Welcome to Add Bus page</h5>
            <h5>Helps for</h5>
            <ul>
                <li>Bus management</li>
                <li>route management</li>
                <li>user management</li>
                <li>booking management</li>
            </ul>
        </div>
        
        <div class="offset-1 col-6 pd">
            <form action="" method="post">
                <div class="form-group">
                    <label >Bus No :</label>
                    <input type="text" name="bus_no" class="form-control" required="">
                </div>
                
                <div class="form-group">
                    <label >Bus Type :</label>
                    <input type="text" name="type" class="form-control" required="">
                </div>

                <div class="form-group">
                    <label>Select route :</label>
                    <select class="form-control" name="r_id">
                        <option>-Select Route name-</option>
                        <?php
                            $connection = mysqli_connect("localhost","root","");
                            $db = mysqli_select_db($connection,"bms");
                            $query = "select r_id from route";
                            $query_run = mysqli_query($connection,$query);
                            while($row = mysqli_fetch_assoc($query_run)){
                                ?>
                                <option><?php echo $row['r_id'];?></option>
                                <?php
                            }
                        ?>
                    </select> <br>
                </div>

                <button type="submit" name="submit" class="btn btn-primary">Add Bus</button>
            </form>
        </div>

    </div>

    <footer class="footer">
        <div class="container-fluid">
            <div class="row">             

            <div class="offset-1 col-lg-2 align-self-center">
                    <div class="text-center">
                        <p>
                            DBMS mini project <br>
                            Dept of CSE.
                        </p>
                    </div>
                </div>

                <div class="offset-1 col-lg-3">
                    <h6>Page creator</h6>
                    <h7>About Team</h7><br>
					Manohar E<br>
                    Kishore A<br>
					5 sem, CSE<br>
				    ACS College of Engineering<br>
                </div>
                
            </div>
        </div>

        <!-- Copyright -->
        <div class="footer-copyright text-center py-3">© 2020 Copyright
        </div>
        <!-- Copyright -->

    </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>

<?php
    if(isset($_POST['submit'])){
        $connection = mysqli_connect("localhost","root","");
        $db = mysqli_select_db($connection,"bms");
        $query = "insert into bus values('$_POST[bus_no]','$_POST[type]', $_POST[r_id], '$_SESSION[mail]')";
        $query_run = mysqli_query($connection,$query);
    ?>
    <script type="text/javascript">
        alert("Bus Added successfully...");
        window.location.href = "add_bus.php";
    </script>
    <?php
    }
?>